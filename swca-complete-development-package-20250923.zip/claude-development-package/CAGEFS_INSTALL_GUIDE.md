# Installing Claude on CloudLinux/CageFS

Since you're on a shared hosting environment with CageFS, you'll need to install everything in your user space.

## Quick Install Commands

```bash
# 1. Download and install NVM (Node Version Manager)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# 2. Reload your shell configuration
source ~/.bashrc

# 3. Install Node.js 20 (required for Claude)
nvm install 20
nvm use 20
nvm alias default 20

# 4. Install Claude Code CLI
npm install -g @anthropic-ai/claude-code

# 5. Verify installation
claude --version

# 6. Configure Claude with your API key
claude login
```

## Alternative: If NVM doesn't work

Some CageFS environments may restrict NVM. In that case, try:

```bash
# 1. Download Node.js binary directly
cd ~
wget https://nodejs.org/dist/v20.11.0/node-v20.11.0-linux-x64.tar.xz
tar -xf node-v20.11.0-linux-x64.tar.xz
mv node-v20.11.0-linux-x64 nodejs

# 2. Add to PATH
echo 'export PATH=$HOME/nodejs/bin:$PATH' >> ~/.bashrc
source ~/.bashrc

# 3. Verify
node --version
npm --version

# 4. Install Claude
npm install -g @anthropic-ai/claude-cli
```

## CloudLinux Selector Method (if available)

If your hosting provider has CloudLinux Selector enabled:

1. Log into cPanel
2. Go to "Select PHP Version" or "Software" section
3. Look for "Node.js Selector"
4. Create a Node.js application
5. Select Node.js version 20.x
6. SSH into your account and use the provided Node.js path

## Troubleshooting

### Permission Denied
If you get permission errors, make sure you're installing in your home directory:
```bash
npm config set prefix ~/.npm-global
export PATH=~/.npm-global/bin:$PATH
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc
```

### CageFS Restrictions
If certain commands are blocked:
- Contact your hosting provider to enable Node.js
- Ask them to add Node.js to CageFS allowed commands
- Request access to npm/node binaries

### Check Available Commands
```bash
# See what's available in your CageFS environment
which node
which npm
cagefsctl --list-enabled
```

## After Installation

1. Upload the claude-development-package to your home directory
2. Extract it: `unzip claude-swca-production-package.zip`
3. Navigate to the directory: `cd claude-development-package`
4. Run Claude with: `claude chat` or `claude code`

## Important Notes

- CageFS limits system access for security
- You may need to request Node.js access from your hosting provider
- All installations are user-space only (no sudo/root access)
- Memory limits may apply - check with `ulimit -a`