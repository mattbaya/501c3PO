# SWCA Claude Development Environment - Production Server

## Overview
This is the Claude development environment for the SWCA Membership Management System on the production server at https://southwilliamstown.org.

## Environment Setup

### Production Server
- **URL**: https://southwilliamstown.org  
- **WordPress**: Production installation
- **Database**: Production database (check wp-config.php for credentials)
- **Plugin Location**: `/wp-content/plugins/swca-membership-management/`
- **Theme**: Active theme with shortcode support

## API Configuration

### Note on API Keys
- API keys should be configured in your local environment
- Never commit API keys to the repository
- Use environment variables or secure storage methods

## WordPress Plugin Development

### Main Plugin: SWCA Membership Management System
- **Production Location**: `/wp-content/plugins/swca-membership-management/`
- **Main File**: `swca-membership-export-corrected.php`
- **Purpose**: Complete non-profit membership management with modular features
- **Architecture**: Modular system with feature toggles and web-based administration
- **Status**: ✅ Active on production server with 197 members imported

### Core Features (Always Available)
- **Member Management** - Complete member profiles with categories and tags
- **Dashboard System** - Password-protected dashboard (`/dashboard` with password "F1v3C0rn3rs")
- **Individual Member Profiles** - Comprehensive member history and contact details
- **Data Export/Import** - Complete migration packages and CSV export functionality
- **Web-Based Administration** - All tools accessible via WordPress admin interface
- **Role-Based Access Control** - Member, Officer, Treasurer, and Committee Chair roles

### Modular Feature System
Each feature can be enabled/disabled via the Settings dashboard:

#### 📧 **Email Management** (Optional)
- Bulk email system with approval workflow
- Email scheduling for advance sending
- Status tracking: draft → pending approval → approved → scheduled → sent
- WYSIWYG editor with letterhead template integration
- Member group targeting and filtering

#### 🎉 **Event Management** (Optional)
- Create and manage events with full details
- RSVP system with guest count and dietary restrictions
- Google Calendar integration for automatic event creation
- Event types: meeting, social, tasting, educational, fundraiser
- Member invitation system

#### 🙋 **Volunteer Signups** (Optional)
- SignUpGenius-style volunteer coordination
- Time-based volunteer slots with skills requirements
- Emergency contact collection
- Confirmation tracking and show-up recording
- Integration with event management

#### 💰 **Financial Management** (Optional)
- Income and expense tracking with categories
- Stripe integration for payment history and fee tracking
- **Web-based Stripe refund processing** with API key security
- Financial reports (monthly, quarterly, annual, custom)
- Net vs gross income differentiation
- **Historical data import via web interface**

#### 🏛️ **Officer Tools** (Optional)
- Meeting agenda creation and management
- Meeting minutes recording with approval workflow
- Administrative document management
- Financial report generation
- Integration with Google Drive for document storage

#### 👥 **Committee Management** (Optional)
- Committee structure management
- Committee membership tracking
- Committee-specific agendas and minutes
- Committee reports for board meetings
- Budget allocation tracking

#### 📁 **Document Management** (Optional)
- File upload with automatic Google Drive organization
- Fiscal year folder structure (2024-2025/committees/events/repair-cafe/)
- Document categorization and tagging
- Integration with meeting agendas and minutes

#### 🛠️ **Administrative Tools** (Web Interface)
- **Stripe Refund Processor** - Secure API key input, transaction analysis, and refund application
- **Historical Data Import** - CSV upload with preview and multi-year tracking
- **Complete Export/Import** - Full database migration packages
- **Renewal Analysis** - Multi-year membership comparison and renewal tracking

### Database Schema (15+ Tables)
- `wp_swca_members`: Core member data with categories and tags
- `wp_swca_financial_transactions`: Income/expense tracking with Stripe fees
- `wp_swca_emails`: Email campaign management
- `wp_swca_email_recipients`: Email delivery tracking
- `wp_swca_events`: Event management with RSVP tracking
- `wp_swca_event_rsvps`: RSVP responses and dietary requirements
- `wp_swca_volunteer_slots`: SignUpGenius-style volunteer opportunities
- `wp_swca_volunteer_signups`: Volunteer coordination
- `wp_swca_agendas`: Meeting agenda management
- `wp_swca_minutes`: Meeting minutes with approval workflow
- `wp_swca_committees`: Committee structure and information
- `wp_swca_committee_members`: Committee membership tracking
- `wp_swca_committee_reports`: Committee reports for board meetings
- `wp_swca_documents`: Document management with Google Drive integration
- `wp_swca_calendar_settings`: API keys and configuration storage

### Integration APIs (All Optional)
- **Stripe API**: Payment tracking and fee calculation
- **Google Calendar API**: Automatic event creation and .ics generation
- **Gmail API**: OAuth-based bulk email sending
- **Google Drive API**: Automatic document organization
- **Google Analytics**: Usage tracking and reporting

## Production URLs & Access

### Access WordPress & SWCA Dashboard
- **Homepage**: https://southwilliamstown.org
- **Admin**: https://southwilliamstown.org/wp-admin
- **SWCA Dashboard**: https://southwilliamstown.org/dashboard (password: F1v3C0rn3rs)
- **Settings**: https://southwilliamstown.org/dashboard/settings
- **Email Management**: https://southwilliamstown.org/dashboard/email-dashboard
- **Event Management**: https://southwilliamstown.org/dashboard/event-dashboard
- **Officer Tools**: https://southwilliamstown.org/dashboard/officer-tools
- **Member Directory**: https://southwilliamstown.org/dashboard/members

### Plugin Management
- **Plugin files are located in**: `/wp-content/plugins/swca-membership-management/`
- **To update plugin**: Upload new files via FTP or WordPress admin interface
- **Database prefix**: Check wp-config.php (may not be 'wp_')

### WP-CLI Commands (if available on server)
```bash
# Check plugin status
wp plugin list

# View SWCA tables
wp db query 'SHOW TABLES LIKE "%swca%";'

# Export members data
wp db export --tables=$(wp db tables '*swca*' --format=csv) swca_backup.sql

# Check member count
wp db query 'SELECT COUNT(*) FROM wp_swca_members;'
```

### WordPress User Roles Created
The plugin automatically creates custom roles with specific capabilities:

- **SWCA Member**: Basic access to dashboard and member directory
- **SWCA Officer**: Can approve emails, create events, manage member profiles
- **SWCA Treasurer**: Full access including financial data and API key management
- **SWCA Committee Chair**: Committee management, agendas, minutes, and reports

### Feature Management
Features can be enabled/disabled via `/dashboard/settings` → Features tab:
- Core features (member management, dashboard) are always enabled
- Optional features can be toggled on/off based on organization needs
- API integrations require proper credentials to function

## Project Specification
- **File**: `project_md_export.md` (979 lines)
- **Scope**: Enterprise Non-Profit Management System
- **Modules**: 15+ toggleable features
- **Integrations**: Stripe, Google Workspace, GravityForms
- **Security**: Financial-grade with AES-256 encryption

## Development Workflow

### SPARC Methodology (Used by Claude Flow)
1. **S**pecification - Requirements analysis
2. **P**seudocode - Algorithm design
3. **A**rchitecture - System design
4. **R**efinement - Code optimization
5. **C**ompletion - Testing & documentation

### Generated Deliverables
- Complete WordPress plugin with activation hooks
- Comprehensive test suite (8 test files)
- Architecture documentation (12 sections)
- Database schema with optimized indexes
- Admin interface with multiple pages
- Security implementation with audit logging

## Key Technical Decisions
- Hierarchical topology for enterprise development complexity
- Free Gemini API prioritized for cost efficiency
- MariaDB over SQLite for production compatibility
- Real database table creation vs manual SQL execution
- Multi-agent coordination for complex integrations

## Production Environment
- **Server**: https://southwilliamstown.org
- **SSL**: Production SSL certificate
- **Database**: Production MySQL/MariaDB
- **PHP Version**: Check server configuration
- **WordPress Version**: Keep updated for security

## Production Deployment Packages

### deployment-packages/
- **swca-membership-management.zip** - Complete WordPress plugin (58KB)
  - All features integrated into web interface
  - No command-line dependencies
  - Ready for production deployment
  - Includes: Main plugin file, readme.txt, installation guide

- **INSTALLATION_GUIDE.md** - Complete deployment documentation
  - Step-by-step installation instructions
  - Web-based tool usage guides
  - Troubleshooting and security notes

### Key Deployment Features
✅ **Web-Only Administration** - No SSH/CLI access required
✅ **Secure API Key Handling** - Stripe keys never stored
✅ **File Upload Interface** - CSV import via browser
✅ **Preview & Confirmation** - Review changes before applying
✅ **Complete Migration** - Export/import entire database
✅ **Multi-Year Tracking** - Historical membership data

## Success Metrics
✅ Complete non-profit membership management system deployed
✅ Modular architecture with feature toggles for customization
✅ 15+ database tables with comprehensive member and organization data
✅ Role-based access control with 4 custom WordPress roles
✅ Password-protected dashboard with multiple management interfaces
✅ Email management with approval workflow and scheduling
✅ Event management with RSVP tracking and volunteer coordination
✅ Financial management with Stripe integration and fee tracking
✅ Officer tools including agendas, minutes, and document management
✅ Committee management system with membership tracking
✅ Google Drive integration for document organization
✅ All features can be enabled/disabled via settings interface
✅ WordPress-native implementation leveraging built-in options system
✅ Responsive design compatible with mobile devices
✅ Secure API key storage and role-based permission system
✅ **Web-based administrative tools** - No command-line access required
✅ **Production-ready deployment package** - Single ZIP file installation
✅ **Complete data migration support** - Export/import between servers
✅ **Stripe integration with secure web interface** - Refund processing via admin panel

## SWCA Membership Management

### Current SWCA Database: wp_swca_members
- **181 members** imported from 2024-2025 season
- **114 members** imported from 2023-2024 season (matched existing where possible)
- **Total unique members**: 181 (some appear in both years)
- **Database table**: `wp_swca_members`

### SWCA Plugin Files & Scripts

#### Main Plugin: swca-membership-export-corrected.php
- **Production Location**: `/wp-content/plugins/swca-membership-management/swca-membership-export-corrected.php`
- **Features**: Shortcodes [swca_stats], [swca_member_directory], export functionality under CRM menu
- **Status**: ✅ Active on production with all features working

#### Key Administrative Tools (Web-Based)
- **Data Import**: Accessible via CRM > Data Import Tools
- **Stripe Refunds**: Accessible via CRM > Stripe Refunds  
- **Export/Import**: Accessible via CRM > Export & Import
- **All tools use web interface**: No command-line access required

### SWCA Deployment & Administration

#### Production Status:
- **Plugin Status**: ✅ Active and running
- **Members Imported**: 197 total members
- **Database Tables**: All 15+ tables created and functional
- **Web Interface**: All administrative tools accessible via CRM menu

#### Critical Production Fixes Applied:
- **Table Prefix Compatibility**: Fixed all hardcoded 'wp_' references to use dynamic `$wpdb->prefix`
- **Table Structure Repair**: Added complete 34-column schema creation on activation
- **Import/Export System**: Full data migration with ZIP packaging and CSV processing
- **Form Validation**: Fixed undefined array key warnings with proper `isset()` checks
- **Member Directory**: Functional display of all imported members with contact details

#### Database Table Structure Issues & Solutions:
- **Problem**: Production tables missing required columns (email_2, email_3, alternate_phone, etc.)
- **Solution**: Created `FIX_TABLE_STRUCTURE.php` to add missing columns to existing data
- **Result**: Complete 34-column schema matching plugin expectations
- **Status**: ✅ All 197 members now display correctly without warnings

#### Web-Based Administration (No CLI Required):
- **Data Import**: CRM > Data Import Tools (upload CSV via browser)
- **Stripe Refunds**: CRM > Stripe Refunds (secure API key input)
- **Export/Import**: CRM > Export & Import (complete migration packages)
- **Member Management**: /dashboard (password-protected interface)
- **Email Management**: /dashboard/email-dashboard (now fixed - no more warnings)
- **Event Management**: /dashboard/event-dashboard
- **Officer Tools**: /dashboard/officer-tools

#### Production File Updates:
- Upload new plugin files via FTP to `/wp-content/plugins/swca-membership-management/`
- Or use WordPress admin: Plugins > Add New > Upload Plugin
- Always backup before making changes

#### Access SWCA Data:
- **Member Dashboard**: https://southwilliamstown.org/dashboard (password: F1v3C0rn3rs)
- **WordPress Admin**: CRM > SWCA Dashboard
- **Export/Import**: CRM > Export & Import
- **Stripe Tools**: CRM > Stripe Refunds
- **Data Import**: CRM > Data Import Tools
- **Stats Shortcode**: [swca_stats] - Shows membership statistics
- **Member Directory**: [swca_member_directory] - Complete member listing (now functional)

### SWCA Database Schema
```sql
-- Key columns in wp_swca_members table:
id, first_name, last_name, partner_first_name, partner_last_name, family_members,
email_1, email_2, email_3, email_4, phone, alternate_phone,
address, city, state, zip_code, alternate_address,
membership_type, status_2024_2025, status_2023_2024, 
membership_amount, donation_amount, total_amount, payment_type,
business_affiliation, on_swca_email_list, notes, 
membership_month, membership_month_2023
```

## CRITICAL TESTING RULE
**For web pages, always test using frontend before telling the user a job is complete. Do not rely on backend/PHP tests alone - verify actual browser output shows expected results.**

This rule was added because shortcode testing showed backend processing working correctly but frontend still displaying raw shortcode text instead of processed content. Always curl the actual webpage or use browser testing to verify functionality.