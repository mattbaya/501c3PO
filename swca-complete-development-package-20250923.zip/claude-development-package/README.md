# SWCA Claude Development Package

This package contains everything needed to run Claude on the production server for SWCA plugin development and maintenance.

## Contents

- `CLAUDE.md` - Complete Claude instructions and documentation
- `plugin/` - SWCA Membership Management plugin files
- `tools/` - Diagnostic and maintenance scripts
- `docs/` - Additional documentation

## Setup Instructions

1. **Upload this entire folder to your production server**
   - Place it in a secure location with appropriate permissions
   - Ensure the folder is not publicly accessible

2. **Configure Claude**
   - Claude will read the CLAUDE.md file for context about your environment
   - No API keys are stored - you'll need to provide them separately

3. **Working Directory**
   - Set Claude's working directory to this folder
   - Claude will have access to all included files and tools

## Key Files

### Plugin File
- `plugin/swca-membership-export-corrected.php` - Main plugin file

### Diagnostic Tools
- `tools/VERIFY_TABLES.php` - Verify database tables structure
- `tools/FIX_TABLE_STRUCTURE.php` - Fix missing database columns
- `tools/swca_diagnostic_script.php` - Comprehensive diagnostics

## Important Notes

- The plugin is already active on production at `/wp-content/plugins/swca-membership-management/`
- Database prefix may not be 'wp_' - check wp-config.php
- All administrative tools are web-based (no CLI required)
- Access dashboard at https://southwilliamstown.org/dashboard (password: F1v3C0rn3rs)

## Security

- Never commit API keys to the repository
- Keep this development folder secure
- Regular backups recommended before changes