#!/bin/bash
# Install Node.js and Claude on CloudLinux/CageFS account

# 1. Install Node.js via NodeSource (user-space)
cd ~
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# 2. Load NVM
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"

# 3. Install Node.js 20 (required for Claude)
nvm install 20
nvm use 20
nvm alias default 20

# 4. Verify installation
node --version
npm --version

# 5. Install Claude globally
npm install -g @anthropic-ai/claude-cli

# 6. Verify Claude installation
claude --version

# 7. Set up Claude API key (you'll need to provide this)
echo "Now run: claude login"
echo "You'll need your Anthropic API key"

# 8. Add NVM to your .bashrc for persistence
echo "" >> ~/.bashrc
echo "# NVM Configuration" >> ~/.bashrc
echo 'export NVM_DIR="$HOME/.nvm"' >> ~/.bashrc
echo '[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"' >> ~/.bashrc
echo '[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"' >> ~/.bashrc

echo "Installation complete! Restart your shell or run: source ~/.bashrc"