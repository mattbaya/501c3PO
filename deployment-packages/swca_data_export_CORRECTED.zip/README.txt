SWCA Data Export - 2025-09-23 01:37:37
============================

Files included:
- members.csv: All member data
- settings.json: Plugin configuration
- database_backup.sql: Database structure

To import: Upload this entire folder via WordPress Admin > SWCA Export/Import
